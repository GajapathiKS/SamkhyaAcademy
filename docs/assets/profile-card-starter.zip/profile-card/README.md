# Profile card project
Build a responsive, semantic profile card. Open index.html in your browser.

Check headings, labels, keyboard focus and narrow-screen layout.